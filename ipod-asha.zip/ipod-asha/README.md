# iPod for the Nokia Asha 210

An MP3 player MIDlet that imitates the iPod classic (6th gen) interface, built for
**Series 40, MIDP 2.1 / CLDC 1.1, 320x240 landscape, no touch**.

The click wheel becomes the D-pad. Everything else is as close to the real thing as a
2013 feature phone allows: the split-view menu with the preview pane, the glossy blue
selection bar, the pill scrub bar, Cover Flow, and a Hold lock that kills the backlight.

## What it does

- Scans the phone memory and the memory card for `.mp3` files (JSR-75)
- Reads **ID3v2.2 / 2.3 / 2.4** and **ID3v1** for title, artist, album and track number
- Pulls the embedded cover out of the `APIC` frame - lazily, by file offset, so a
  hundred covers do not sit in a 2 MB heap
- Groups into **Artists / Albums / Songs**, plus an **On-The-Go** playlist
- Shuffle (off / songs), repeat (off / one / all), volume, sliding transitions
- Caches the whole library in RMS, so only the first launch is slow

## Screens

| Screen | What is on it |
| --- | --- |
| Menu | Split view: list on the left, cover + labels or a mini Now Playing on the right |
| Now Playing | Cover beside the text on a landscape screen (above it on a tall one), marquee title, scrub bar with elapsed / remaining |
| Cover Flow | Album carousel; side covers projected in perspective, reflections under all of them |
| Flip | Select an album and the case turns over to show its track listing on the back |
| Updating Library | Progress while scanning and tag-reading |
| Hold | Padlock, current track, backlight off after 3 s |
| About | Counts, free heap, and the key map |

## Keys

| Key | Does |
| --- | --- |
| Up / Down | Scroll (the click wheel) |
| Right / OK | Open the highlighted row |
| Left / Back / Backspace | Go back |
| Left softkey | Jump to the main menu |
| OK | Play / pause, on Now Playing |
| Left / Right | Previous / next; **hold** to scrub 5 s at a time |
| Up / Down | Volume, on Now Playing |
| Space | Play / pause, from anywhere |
| M | Jump to Now Playing |
| H | Hold - locks the keys, dims the screen |
| A | Add the current song to On-The-Go |
| A-Z | Type a letter to jump down a long list |

## Building

You need:

1. **A JDK, version 8 to 21.** Anything newer may refuse `-source 8`.
2. **`tools/proguard.jar`** - take `lib/proguard.jar` out of any
   [ProGuard 7.x release](https://github.com/Guardsquare/proguard/releases).

Then:

```bash
.\build.ps1        # Windows
./build.sh         # macOS / Linux
```

Output is `dist/ipod.jar` and `dist/ipod.jad`.

> **Keep the JDK on a short path.** The Java launcher still uses `MAX_PATH`
> internally; from a folder more than 260 characters deep it fails with
> `could not find java.dll` before it ever reads your arguments.

### Tests

```bash
.\test.ps1
```

There is no MIDP emulator involved. `test/` holds real `java.io`-backed versions of
`Connector` and `FileConnection`; put ahead of `stubs/` on the classpath, they let the
tag parser read actual files on a desktop JVM. `ipod.Harness` then builds synthetic MP3s
and checks them:

- ID3v2.3 text frames, and `APIC` artwork extracted byte-for-byte by offset
- ID3v2.2's three-letter frame ids (`TT2`, `TP1`)
- ID3v1 trailer as a fallback when there is no v2 tag
- All four v2 text encodings: Latin-1, UTF-16 with a BOM, UTF-16BE, UTF-8
- Untagged files falling back to the filename
- `Library.group()`: album and artist counts, disc ordering, and - the fiddly part -
  that every `track -> album` and `artist -> album` index still points at the right
  thing after the album list is re-sorted
- The directory walk: that phone-memory `predefgallery/Music` is found, that nested
  folders and uppercase `.MP3` are picked up, that `system/` is skipped and non-audio
  files are ignored
- `Sort` filing "The Ferry Lights" under F, `Gfx.time`, `Str`

43 checks, all passing.

### What the built JAR was verified to be

- Class file version **46** for every class - CLDC 1.1 will not load 50+
- `Code/StackMap` on 141 methods, **no `StackMapTable`** - the CLDC preverification form
  (a leftover `StackMapTable` *string* survives in the constant pool because we do not
  shrink; no such attribute is actually attached)
- No `invokedynamic`, no `NestHost`/`NestMembers`
- Referenced platform classes are all CLDC 1.1 / MIDP 2.0 / JSR-75 / JSR-135 -
  `StringBuffer` and `Vector`, no `StringBuilder`, no collections framework
- The `stubs/` classes are not in the JAR; `icon.png` is

### Why the build looks like that

J2ME tooling has mostly rotted away, so this project avoids needing any of it:

- **No SDK.** `stubs/` holds compile-time-only declarations of every
  `javax.microedition.*` class the app touches (plus Nokia's `DeviceControl`). They are
  compiled to a separate directory, used as `-classpath`, and never enter the JAR - the
  phone supplies the real implementations.
- **No `preverify.exe`.** ProGuard's `-microedition` flag writes the CLDC `StackMap`
  attribute that a MIDP VM insists on, and `-target 1.2` rewrites the class file version
  down to 46. It is configured not to shrink, optimise or obfuscate; it is doing the job
  of the preverifier and nothing else.
- **No `StringBuilder`.** `javac` turns `"a" + b` into `java.lang.StringBuilder` at
  `-target 5` and above, and CLDC 1.1 does not have that class - the MIDlet would install
  fine and then die with `NoClassDefFoundError` the first time it drew a screen. Every
  join in the source goes through `Str`, which uses `StringBuffer`. **If you add code,
  do not use `+` on strings.**
- **No private access across inner classes.** `Engine.autoAdvance` and two fields in
  `IPodMIDlet` are package-private on purpose: Java 11+ compiles private cross-nest
  access as nestmates rather than synthetic bridges, which an old VM cannot verify.

## Installing on the phone

1. Copy **both** `ipod.jar` and `ipod.jad` into the same folder on the memory card.
2. On the phone, open `ipod.jad` from **File manager** and install.
3. **Important:** in **Application manager -> iPod -> Settings**, set
   **Read user data** to **Ask first time**. Unsigned MIDlets cannot get blanket file
   permission on Series 40, and the default setting will prompt once per file while the
   library scans.
4. First launch scans and reads tags - a few minutes for a full card. After that it
   loads from the RMS cache. Rescan from **Settings -> Update Library**.

## Layout

```
src/ipod/
  IPodMIDlet.java   lifecycle
  Shell.java        canvas, screen stack, status bar, transitions, Hold, key routing
  UIScreen.java     base class for a screen
  MenuScreen.java   the split view
  MenuItem.java     one row
  Menus.java        every menu, and what selecting a row does
  NowPlaying.java   cover, marquee, scrub bar, volume HUD, toast
  CoverFlow.java    album carousel with perspective-projected side covers
  FlipScreen.java   the cover-turns-over-to-the-track-list animation
  ScanScreen.java   library update progress
  AboutScreen.java  counts and key map
  DiagScreen.java   what the last scan saw, for when it finds nothing
  Library.java      file walk, grouping, sorting
  Track.java        one song
  Id3.java          tag and artwork parsing
  ArtCache.java     background cover decoding, 12-entry LRU
  Engine.java       MMAPI player, queue, shuffle, repeat, On-The-Go
  Store.java        RMS persistence in 6 KB chunks
  Settings.java     preferences
  Sort.java         merge sort + "The Beatles" filed under B
  Theme.java        every colour and font
  Gfx.java          gradients, chevrons, battery, scaling, perspective, mm:ss
  ScrubBar.java     the pill bar
  Str.java          string joining without StringBuilder
stubs/              compile-time API declarations, never shipped
test/               java.io-backed Connector/FileConnection + ipod.Harness
build/              manifest, ProGuard config, icon generator
res/icon.png        app icon
build.ps1 build.sh  build
test.ps1            run the smoke test
```

## Screen shape

The Asha 210 is a QWERTY bar phone, so its 2.4" QVGA panel is **landscape 320x240** -
not the portrait 240x320 the non-QWERTY Ashas use. Every screen sizes itself from
`Canvas.getWidth()/getHeight()`, and `NowPlaying` and `About` switch layout when the
screen is wider than it is tall, so the app is correct either way round.

## Cover Flow

The side covers are not simply drawn smaller. `Gfx.perspective` maps each source column
to its own screen x and its own height, so a square cover becomes a trapezoid that is
taller on the edge nearest the viewer, with the far edge shaded down to about 55%
brightness - a real projective texture map, just done a column at a time.

What a 2013 feature phone cannot do is re-project a cover every frame, so the rotation
angle is fixed (64 degrees) and each projection is built once per album per side and
cached; moving between covers is a positional slide. At most one projection is built per
frame, and a cover that has not been projected yet is drawn flat, so scrolling never
stalls. A projected 75 px cover is roughly 40x75 pixels - about 12 KB - which is why
this is affordable at all on a 2 MB heap.

## When the library scans to zero

**Settings > Diagnostics** reports what the last scan actually saw: whether JSR-75 is
present, which roots the phone handed back, how many folders were walked, and the first
error that got swallowed. **Settings > Browse Files** walks the filesystem as the MIDlet
sees it and will play any `.mp3` you point it at, so you can confirm a file is reachable
even if the scan missed it.

Both also appear in the Music menu when the library is empty, which is when you need
them.

The first real bug found this way: the walk used to skip `predefgallery/`, which is
exactly where phone-memory Music lives on Series 40 - so a phone with music in
`Music/` scanned to zero tracks. The scan now only skips `system/`, `private/` and
`sys/`, includes hidden entries, and there is a test for it (`scanning()` in
`ipod.Harness`) that fails if that folder is skipped again.

## The flip

Choosing an album in Cover Flow turns the case over. The front half of the turn is the
cover; the back half is a panel rendered once with the track listing on it. Both are
nearly edge-on as they pass 90 degrees, which is what lets a 96 px cover be swapped for a
200x170 panel without the join showing - the same trick a real card flip uses. The cover
also grows as it turns so the two heights match by the time they cross.

Six projections is far too much work to do inside a frame here, so they are all built on
a background thread first. Until they are ready the cover simply sits where Cover Flow
left it; if the build takes more than 1.5 s or throws, the flip is abandoned and the list
opens directly. The UI thread never waits on it, and any key skips to the listing.

The turn is advanced in `tick()`, not `paint()`: finishing swaps the top of the screen
stack, which must not happen in the middle of rendering it.

## Known limits

- Seeking needs the platform to accept `setMediaTime`. Some Series 40 builds refuse the
  `file://` locator entirely, in which case the player falls back to an `InputStream`
  and scrubbing may not work - playback still does.
- The library is capped at 1500 tracks and 8 directory levels, to stay inside the heap.
- Artwork inside an *unsynchronised* ID3 tag is skipped: the offsets are not reliable
  without rewriting the whole tag in memory.
- Album art is cached at the sizes actually drawn, twelve at a time. Cover Flow keeps
  two sizes, so a very large library will re-decode as you scroll it.
